package com.darkness.sparkwomen;

public interface MyOnClickListener {
    void onItemClicked(int position);
}
